import KButton from './button.vue';

export { KButton };